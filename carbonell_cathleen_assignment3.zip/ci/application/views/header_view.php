<!DOCTYPE html>
<html lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title>|| FITSTAR ||</title>
 <!--?php if($title){

 	echo  "<title>|| $title ||</title>";}
 	else{
 		echo "<title>|| FITSTAR ||</title>";
 	} ?-->

 <!-- CSS -->
 <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/bootstrap/css/bootstrap.min.css" />
 <link href="<?php echo base_url();?>/bootstrap-editable/css/bootstrap-editable.css" rel="stylesheet">
 <link href="<?php echo base_url();?>/featherlight/src/featherlight.css" rel="stylesheet">
 <link href="<?php echo base_url();?>/featherlight/src/featherlight.gallery.css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/css/main.css" />

 <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

 <!-- JQUERY -->

 <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
 <script src="<?php echo base_url();?>/bootstrap/js/bootstrap.min.js"></script>
 <script src="<?php echo base_url();?>/bootstrap-editable/js/bootstrap-editable.js"></script>
 <script src="<?php echo base_url();?>/featherlight/src/featherlight.js"></script>
 <script src="<?php echo base_url();?>/featherlight/src/featherlight.gallery.js"></script>
 <script src="<?php echo base_url();?>/js/main.js"></script>





</head>
<body>
<div class="container">

<div class="navbar-header logo">
	<a href="/ci"><img src="<?php echo base_url();?>/img/logo2.png"></a>
</div>


 