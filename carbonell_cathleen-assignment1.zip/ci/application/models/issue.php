<?php 
class Issue extends CI_Model {

	public $issue_id;
	public $publication_id;
	public $issue_number;
	public $issue_date_publication;
	public $issue_cover
}