<!DOCTYPE html>
<html lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title>|| FITSTAR ||</title>
 <!--?php if($title){

 	echo  "<title>|| $title ||</title>";}
 	else{
 		echo "<title>|| FITSTAR ||</title>";
 	} ?-->

 <!-- CSS -->
 <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/bootstrap/css/bootstrap.min.css" />
 <link href="<?php echo base_url();?>/bootstrap-editable/css/bootstrap-editable.css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/css/main.css" />

 <!-- JQUERY -->
 <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
 <script src="<?php echo base_url();?>/bootstrap/js/bootstrap.min.js"></script>
 <script src="<?php echo base_url();?>/bootstrap-editable/js/bootstrap-editable.js"></script>
 <script src="<?php echo base_url();?>/js/main.js"></script>





</head>
<body>
	<div id="content">
		<div class="logo left">
			<a href="/ci"><img src="<?php echo base_url();?>/img/logo.png"></a>
		</div>
 