<?php 
class Publication extends CI_Model {

	//int Publication Unique ID
	public $publication_id;

	//string Publication Name
	public $publication_name;	
}
